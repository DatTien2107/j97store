/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import utils.DBUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Account;

/**
 *
 * @author ADMIN
 */
public class AccountDAO extends DBUtils implements Accessible<Account> {

    public AccountDAO() {
    }

    @Override
    public int insertRec(Account obj) {
        int rowsAffected = 0;
        try ( Connection conn = getConnection();  PreparedStatement ps = conn.prepareStatement("INSERT INTO accounts (account, pass, lastName, firstName, birthday, gender, phone, isUse, roleInSystem) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
            ps.setString(1, obj.getAccount());
            ps.setString(2, obj.getPass());
            ps.setString(3, obj.getLastName());
            ps.setString(4, obj.getFirstName());
            ps.setDate(5, new java.sql.Date(obj.getBirthday().getTime()));
            ps.setBoolean(6, obj.isGender());
            ps.setString(7, obj.getPhone());
            ps.setBoolean(8, obj.isUse());
            ps.setInt(9, obj.getRoleInSystem());
            rowsAffected = ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(AccountDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rowsAffected;
    }

    @Override
    public int updateRec(Account obj) {
        int rowsAffected = 0;
        try ( Connection conn = getConnection();  PreparedStatement ps = conn.prepareStatement("UPDATE accounts SET pass = ?, lastName = ?, firstName = ?, birthday = ?, gender = ?, phone = ?, isUse = ?, roleInSystem = ? WHERE account = ?")) {
            ps.setString(1, obj.getPass());
            ps.setString(2, obj.getLastName());
            ps.setString(3, obj.getFirstName());
            ps.setDate(4, new java.sql.Date(obj.getBirthday().getTime()));
            ps.setBoolean(5, obj.isGender());
            ps.setString(6, obj.getPhone());
            ps.setBoolean(7, obj.isUse());
            ps.setInt(8, obj.getRoleInSystem());
            ps.setString(9, obj.getAccount());
            rowsAffected = ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(AccountDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rowsAffected;
    }

    @Override
    public int deleteRec(Account obj) {
        int rowsAffected = 0;
        try ( Connection conn = getConnection();  PreparedStatement ps = conn.prepareStatement("DELETE FROM accounts WHERE account = ?")) {
            ps.setString(1, obj.getAccount());
            rowsAffected = ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(AccountDAO.class.getName()).log(Level.SEVERE, "Error deleting account: " + obj.getAccount(), ex);
        }
        return rowsAffected;
    }

    @Override
    public Account getObjectById(String id) {
        try ( Connection conn = getConnection();  PreparedStatement ps = conn.prepareStatement("SELECT * FROM accounts WHERE account = ?")) {
            ps.setString(1, id);
            try ( ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Account account = new Account();
                    account.setAccount(rs.getString("account"));
                    account.setPass(rs.getString("pass"));
                    account.setLastName(rs.getString("lastName"));
                    account.setFirstName(rs.getString("firstName"));
                    account.setBirthday(rs.getDate("birthday"));
                    account.setGender(rs.getBoolean("gender"));
                    account.setPhone(rs.getString("phone"));
                    account.setUse(rs.getBoolean("isUse"));
                    account.setRoleInSystem(rs.getInt("roleInSystem"));
                    return account;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(AccountDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public List<Account> listAll() {
        List<Account> accounts = new ArrayList<>();
        try ( Connection conn = getConnection();  PreparedStatement ps = conn.prepareStatement("SELECT * FROM accounts");  ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Account account = new Account();
                account.setAccount(rs.getString("account"));
                account.setPass(rs.getString("pass"));
                account.setLastName(rs.getString("lastName"));
                account.setFirstName(rs.getString("firstName"));
                account.setBirthday(rs.getDate("birthday"));
                account.setGender(rs.getBoolean("gender"));
                account.setPhone(rs.getString("phone"));
                account.setUse(rs.getBoolean("isUse"));
                account.setRoleInSystem(rs.getInt("roleInSystem"));
                accounts.add(account);

            }
        } catch (SQLException ex) {
            Logger.getLogger(AccountDAO.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        return accounts;
    }

    public List<Account> listAllSearch(String search) {
        List<Account> accounts = new ArrayList<>();
        try {
            Connection conn = getConnection();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM accounts WHERE firstName LIKE ? OR lastName LIKE ? ");
            ps.setString(1, "%" + search + "%");
            ps.setString(2, "%" + search + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Account account = new Account();
                account.setAccount(rs.getString("account"));
                account.setPass(rs.getString("pass"));
                account.setLastName(rs.getString("lastName"));
                account.setFirstName(rs.getString("firstName"));
                account.setBirthday(rs.getDate("birthday"));
                account.setGender(rs.getBoolean("gender"));
                account.setPhone(rs.getString("phone"));
                account.setUse(rs.getBoolean("isUse"));
                account.setRoleInSystem(rs.getInt("roleInSystem"));
                accounts.add(account);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AccountDAO.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        return accounts;
    }

    public Account getAccountByUsernameAndPassword(String username, String password) {
        try ( Connection conn = getConnection();  PreparedStatement ps = conn.prepareStatement("SELECT * FROM accounts WHERE account = ? AND pass = ?")) {
            ps.setString(1, username);
            ps.setString(2, password);
            try ( ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Account account = new Account();
                    account.setAccount(rs.getString("account"));
                    account.setPass(rs.getString("pass"));
                    account.setLastName(rs.getString("lastName"));
                    account.setFirstName(rs.getString("firstName"));
                    account.setBirthday(rs.getDate("birthday"));
                    account.setGender(rs.getBoolean("gender"));
                    account.setPhone(rs.getString("phone"));
                    account.setUse(rs.getBoolean("isUse"));
                    account.setRoleInSystem(rs.getInt("roleInSystem"));
                    return account;

                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(AccountDAO.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public static void main(String[] args) {
        System.out.println(new AccountDAO().listAllSearch("Hưng"));
    }
}
