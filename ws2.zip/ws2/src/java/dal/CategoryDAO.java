/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Category;
import utils.DBUtils;

/**
 *
 * @author ADMIN
 */
public class CategoryDAO extends DBUtils implements Accessible<Category> {

    @Override
    public int insertRec(Category obj) {
        int rowsAffected = 0;
        try {
            String sql = "INSERT INTO [categories] (categoryName, memo) VALUES (?, ?)";
            Connection conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, obj.getCategoryName());
            ps.setString(2, obj.getMemo());
            rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    obj.setTypeId(rs.getInt(1));
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(CategoryDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rowsAffected;
    }

    @Override
    public int updateRec(Category obj) {
        int rowsAffected = 0;
        try {
            String sql = "UPDATE [categories] SET categoryName = ?, memo = ? WHERE typeId = ?";
            Connection conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, obj.getCategoryName());
            ps.setString(2, obj.getMemo());
            ps.setInt(3, obj.getTypeId());
            rowsAffected = ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CategoryDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rowsAffected;
    }

    @Override
    public int deleteRec(Category obj) {
        int rowsAffected = 0;
        try {
            String sql = "DELETE FROM [categories] WHERE typeId = ?";
            Connection conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, obj.getTypeId());
            rowsAffected = ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CategoryDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rowsAffected;
    }

    @Override
    public Category getObjectById(String id) {
        try {
            String sql = "SELECT * FROM [categories] WHERE typeId = ?";
            Connection conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int typeId = rs.getInt("typeId");
                String categoryName = rs.getString("categoryName");
                String memo = rs.getString("memo");
                return new Category(typeId, categoryName, memo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CategoryDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public List<Category> listAll() {
        List<Category> listCategory = new ArrayList<>();
        try {
            String sql = "SELECT * FROM [categories]";
            Connection conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int typeId = rs.getInt("typeId");
                String categoryName = rs.getString("categoryName");
                String memo = rs.getString("memo");
                Category category = new Category(typeId, categoryName, memo);
                listCategory.add(category);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CategoryDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listCategory;
    }
    
        public List<Category> listAllSearch(String search) {
        List<Category> listCategory = new ArrayList<>();
        try {
            String sql = "SELECT * FROM [categories] WHERE categoryName LIKE ?";
            Connection conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + search + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int typeId = rs.getInt("typeId");
                String categoryName = rs.getString("categoryName");
                String memo = rs.getString("memo");
                Category category = new Category(typeId, categoryName, memo);
                listCategory.add(category);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CategoryDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listCategory;
    }
    

    public static void main(String[] args) {
        System.out.println(new CategoryDAO().listAll());
    }

}
