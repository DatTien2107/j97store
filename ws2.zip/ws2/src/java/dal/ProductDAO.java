/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Account;
import model.Category;
import model.Product;
import utils.DBUtils;

/**
 *
 * @author ADMIN
 */
public class ProductDAO extends DBUtils implements Accessible<Product> {

    @Override
    public int insertRec(Product obj) {
        try ( Connection conn = getConnection();  PreparedStatement ps = conn.prepareStatement("INSERT INTO products (productId, productName, productImage, brief, postedDate, typeId, account, unit, price, discount) " + "VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, ?, ?, ?, ?, ?)")) {
            ps.setString(1, obj.getProductId());
            ps.setString(2, obj.getProductName());
            ps.setString(3, obj.getProductImage());
            ps.setString(4, obj.getBrief());
            ps.setInt(5, obj.getCategory().getTypeId());
            ps.setString(6, obj.getAccount().getAccount());
            ps.setString(7, obj.getUnit());
            ps.setInt(8, obj.getPrice());
            ps.setInt(9, obj.getDiscount());
            int rowsAffected = ps.executeUpdate();
            return rowsAffected;
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, "Error inserting product", ex);
            throw new RuntimeException("Error inserting product", ex);
        }
    }

    @Override
    public int updateRec(Product obj) {
        try ( Connection conn = getConnection();  PreparedStatement ps = conn.prepareStatement("UPDATE products SET productName = ?, brief = ?, typeId = ?, unit = ?, price = ?, discount = ? WHERE productId = ?")) {
            ps.setString(1, obj.getProductName());
            ps.setString(2, obj.getBrief());
            ps.setInt(3, obj.getCategory().getTypeId());
            ps.setString(4, obj.getUnit());
            ps.setInt(5, obj.getPrice());
            ps.setInt(6, obj.getDiscount());
            ps.setString(7, obj.getProductId());
            int rowsAffected = ps.executeUpdate();
            return rowsAffected;
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, "Error updating product", ex);
            throw new RuntimeException("Error updating product", ex);
        }
    }

    @Override
    public int deleteRec(Product obj) {
        try ( Connection conn = getConnection();  PreparedStatement ps = conn.prepareStatement("DELETE FROM products WHERE productId = ?")) {
            ps.setString(1, obj.getProductId());
            int rowsAffected = ps.executeUpdate();
            return rowsAffected;
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, "Error deleting product", ex);
            throw new RuntimeException("Error deleting product", ex);
        }
    }

    @Override
    public Product getObjectById(String id) {
        try ( Connection conn = getConnection();  PreparedStatement ps = conn.prepareStatement("SELECT p.*, c.typeId, c.categoryName, c.memo, a.account, a.firstName, a.lastName " + "FROM products p " + "JOIN categories c ON p.typeId = c.typeId " + "JOIN accounts a ON p.account = a.account " + "WHERE p.productId = ?")) {
            ps.setString(1, id);
            try ( ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String productId = rs.getString("productId");
                    String productName = rs.getString("productName");
                    String productImage = rs.getString("productImage");
                    String brief = rs.getString("brief");
                    java.sql.Date postedDate = rs.getDate("postedDate");
                    int typeId = rs.getInt("typeId");
                    String categoryName = rs.getString("categoryName");
                    String memo = rs.getString("memo");
                    String accountId = rs.getString("account");
                    String firstName = rs.getString("firstName");
                    String lastName = rs.getString("lastName");
                    String unit = rs.getString("unit");
                    int price = rs.getInt("price");
                    int discount = rs.getInt("discount");
                    Category category = new Category(typeId, categoryName, memo);
                    Account account = new Account(accountId, null, lastName, firstName, null, false, null, true, 2);
                    return new Product(productId, productName, productImage, brief, postedDate, category, account, unit, price, discount);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, "Error fetching product by ID", ex);
            throw new RuntimeException("Error fetching product by ID", ex);
        }
        return null;
    }

    @Override
    public List<Product> listAll() {
        List<Product> products = new ArrayList<>();
        try ( Connection conn = getConnection();  PreparedStatement ps = conn.prepareStatement("SELECT p.*, c.typeId, c.categoryName, c.memo, a.account, a.firstName, a.lastName " + "FROM products p " + "JOIN categories c ON p.typeId = c.typeId " + "JOIN accounts a ON p.account = a.account");  ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String productId = rs.getString("productId");
                String productName = rs.getString("productName");
                String productImage = rs.getString("productImage");
                String brief = rs.getString("brief");
                java.sql.Date postedDate = rs.getDate("postedDate");
                int typeId = rs.getInt("typeId");
                String categoryName = rs.getString("categoryName");
                String memo = rs.getString("memo");
                String accountId = rs.getString("account");
                String firstName = rs.getString("firstName");
                String lastName = rs.getString("lastName");
                String unit = rs.getString("unit");
                int price = rs.getInt("price");
                int discount = rs.getInt("discount");
                Category category = new Category(typeId, categoryName, memo);
                Account account = new Account(accountId, null, lastName, firstName, null, false, null, true, 2);
                Product product = new Product(productId, productName, productImage, brief, postedDate, category, account, unit, price, discount);
                products.add(product);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, "Error fetching products", ex);
        }
        return products;
    }

    public List<Product> listAllSearch(String search) {
        List<Product> products = new ArrayList<>();
        try {
            Connection conn = getConnection();
            PreparedStatement ps = conn.prepareStatement("SELECT p.*, c.typeId, c.categoryName, c.memo, a.account, a.firstName, a.lastName " 
                    + "FROM products p " + "JOIN categories c ON p.typeId = c.typeId " 
                    + "JOIN accounts a ON p.account = a.account WHERE p.productName LIKE ? ");
            ps.setString(1,"%" +  search + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String productId = rs.getString("productId");
                String productName = rs.getString("productName");
                String productImage = rs.getString("productImage");
                String brief = rs.getString("brief");
                java.sql.Date postedDate = rs.getDate("postedDate");
                int typeId = rs.getInt("typeId");
                String categoryName = rs.getString("categoryName");
                String memo = rs.getString("memo");
                String accountId = rs.getString("account");
                String firstName = rs.getString("firstName");
                String lastName = rs.getString("lastName");
                String unit = rs.getString("unit");
                int price = rs.getInt("price");
                int discount = rs.getInt("discount");
                Category category = new Category(typeId, categoryName, memo);
                Account account = new Account(accountId, null, lastName, firstName, null, false, null, true, 2);
                Product product = new Product(productId, productName, productImage, brief, postedDate, category, account, unit, price, discount);
                products.add(product);
            }
        }catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, "Error fetching products", ex);
        }
        return products;
    }

}
