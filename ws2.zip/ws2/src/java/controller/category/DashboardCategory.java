/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller.category;

import dal.CategoryDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Account;
import model.Category;

public class DashboardCategory extends HttpServlet {

    private CategoryDAO categoryDAO = null;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        categoryDAO = new CategoryDAO();
        HttpSession session = request.getSession();
        boolean noPermission = false;
        if (session != null && session.getAttribute("account") != null) {
            Account acc = (Account) session.getAttribute("account");

            String action = request.getParameter("action") == null
                    ? ""
                    : request.getParameter("action");
            String url = "category/listCategory.jsp";
            List<Category> listCategory;
            switch (action) {
                case "showCategory":
                    url = "category/listCategory.jsp";
                    String search = request.getParameter("search");
                    if (search == null) {
                        search = "";
                    }
                    listCategory = categoryDAO.listAllSearch(search);
                    request.setAttribute("search", search);
                    request.setAttribute("listCategory", listCategory);
                    break;
                case "addCategory":
                    if (acc.getRoleInSystem() != 1) {
                        noPermission = true;
                    }
                    url = "category/addCategory.jsp";
                    break;
                case "updateCategory":
                    if (acc.getRoleInSystem() != 1) {
                        noPermission = true;
                    }
                    url = editCategory(request, response);
                    break;
                case "deleteCategory":
                    if (acc.getRoleInSystem() != 1) {
                        noPermission = true;
                    }
                    url = deleteCategory(request, response);
                    break;
                default:
                    url = "category/listCategory.jsp";
                    listCategory = categoryDAO.listAll();
                    request.setAttribute("listCategory", listCategory);
            }
            if (noPermission) {
                response.sendRedirect("no-permission.jsp");
            } else {
                request.getRequestDispatcher(url).forward(request, response);
            }
        } else {
            response.sendRedirect("login.jsp");
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        categoryDAO = new CategoryDAO();
        String action = request.getParameter("action");
        switch (action) {
            case "addCategory":
                addCategory(request, response);
                break;
            case "updateCategory":
                updateCategoryDoPost(request, response);
                break;
            default:

        }
        response.sendRedirect("category");
    }

    private void addCategory(HttpServletRequest request, HttpServletResponse response) throws IOException {

        HttpSession session = request.getSession();
        if (session != null && session.getAttribute("account") != null) {
            Account acc = (Account) session.getAttribute("account");
            if (acc.getRoleInSystem() == 1) {
                String categoryName = request.getParameter("categoryName");
                String memo = request.getParameter("memo");
                Category newCategory = new Category(0, categoryName, memo);
                // Set typeId to 0 for auto-increment          
                try {
                    categoryDAO.insertRec(newCategory);
                } catch (Exception ex) {
                    request.setAttribute("errorMessage", "An error occurred while adding the category.");
                }

            }
        }

    }

    private String editCategory(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        if (session != null && session.getAttribute("account") != null) {
            Account acc = (Account) session.getAttribute("account");
            if (acc.getRoleInSystem() == 1) {
                String typeId = request.getParameter("typeId");
                String url = "category/updateCategory.jsp";
                //get data from DB
                Category category = categoryDAO.getObjectById(typeId);
                if (category == null) {
                    List<Category> listCategory = categoryDAO.listAll();
                    request.setAttribute("listCategory", listCategory);
                    url = "category/listCategory.jsp";
                    return url;
                }

                //set to request 
                request.setAttribute("category", category);
                return url;
            }
        }
        return null;
    }

    private void updateCategoryDoPost(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession();
            if (session != null && session.getAttribute("account") != null) {
                Account acc = (Account) session.getAttribute("account");
                if (acc.getRoleInSystem() == 1) {
                    int typeId = Integer.parseInt(request.getParameter("typeId"));
                    String categoryName = request.getParameter("categoryName");
                    String memo = request.getParameter("memo");
                    Category updatedCategory = new Category(typeId, categoryName, memo);
                    categoryDAO.updateRec(updatedCategory);
                }

            }

        } catch (Exception ex) {
            request.setAttribute("errorMessage", "An error occurred while updating the category: " + ex.getMessage());
        }
    }

    private String deleteCategory(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        if (session != null && session.getAttribute("account") != null) {
            Account acc = (Account) session.getAttribute("account");
            if (acc.getRoleInSystem() == 1) {
                String typeId = request.getParameter("typeId");
                List<Category> listCategory = categoryDAO.listAll();
                request.setAttribute("listCategory", listCategory);
                try {
                    Category categoryToDelete = categoryDAO.getObjectById(typeId);
                    categoryDAO.deleteRec(categoryToDelete);
                } catch (Exception ex) {
                    request.setAttribute("errorMessage", "An error occurred while deleting the category: " + ex.getMessage());
                }
                return "category/listCategory.jsp";
            }
        }
        return null;

    }

}
