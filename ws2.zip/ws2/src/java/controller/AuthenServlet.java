/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dal.AccountDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Account;

public class AuthenServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action") == null ? "default" : request.getParameter("action");
        switch (action) {
            case "logOut":
                logOutDoGet(request, response);
                break;
            case "login":
            default:
                request.getRequestDispatcher("login.jsp").forward(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action") == null
                ? "default"
                : request.getParameter("action");
        switch (action) {
            case "login":
                loginDoPost(request, response);
                break;
            default:
                throw new AssertionError();
        }
    }

    private void loginDoPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        AccountDAO accountDAO = new AccountDAO();
        Account account = accountDAO.getAccountByUsernameAndPassword(username, password);
        if (account != null) {
            // Login successful        
            HttpSession session = request.getSession();
            session.setAttribute("account", account);
            response.sendRedirect("home.jsp");
            // Redirect to the home page   
        } else {
            // Login failed     
            request.setAttribute("error", "Invalid username or password");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }

    private void logOutDoGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        try {
            HttpSession session = request.getSession();
            session.invalidate();
            // Destroy the session        
            response.sendRedirect("authen");
            // Redirect to the login page      
        } catch (Exception e) {
            System.out.println("AuthenServlet: " + e.getMessage());
            request.setAttribute("error", "Error occurred during logout. Please try again.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
