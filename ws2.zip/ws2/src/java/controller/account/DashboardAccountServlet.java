/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller.account;

import dal.AccountDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Account;

public class DashboardAccountServlet extends HttpServlet {
    
    private AccountDAO accountDAO = null;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            accountDAO = new AccountDAO();
            HttpSession session = request.getSession();
            if (session != null && session.getAttribute("account") != null) {
                boolean noPermission = false;
                Account acc = (Account) session.getAttribute("account");
                String url = "account/dashboardAccount.jsp";
                String action = request.getParameter("action") == null
                        ? ""
                        : request.getParameter("action");
                switch (action) {
                    case "addAccount":
                        if (acc.getRoleInSystem() != 1) {
                            noPermission = true;
                        }
                        url = "account/addAccount.jsp";
                        break;
                    case "updateAccount":
                        if (acc.getRoleInSystem() != 1) {
                            noPermission = true;
                        }
                        
                        url = updateAccountDoGet(request);
                        break;
                    case "isUseAccount":
                        if (acc.getRoleInSystem() != 1) {
                            noPermission = true;
                        }
                        url = isUseAccount(request);
                        break;
                    case "deleteAccount":
                        if (acc.getRoleInSystem() != 1) {
                            noPermission = true;
                        }
                        deleteAccount(request, response);
                        break;
                    case "showAccount":
                        String search = request.getParameter("search");
                        if(search == null) {
                            search = "";
                        }
                        List<Account> accounts = accountDAO.listAllSearch(search);
                        request.setAttribute("search", search);
                        request.setAttribute("accounts", accounts);
                        url = "account/dashboardAccount.jsp";
                }
                if (noPermission) {
                    response.sendRedirect("no-permission.jsp");
                } else {
                    request.getRequestDispatcher(url).forward(request, response);
                }
                
            } else {
                response.sendRedirect("login.jsp");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action") == null
                ? ""
                : request.getParameter("action");
        switch (action) {
            case "addAccount":
                addAccount(request, response);
                break;
            case "updateAccount":
                updateAccount(request, response);
                break;
            default:
                throw new AssertionError();
        }
        response.sendRedirect("MainController?action=showAccount");
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet DashboardAccount</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet DashboardAccount at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    
    private void addAccount(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        if (session != null && session.getAttribute("account") != null) {
            Account acc = (Account) session.getAttribute("account");
            if (acc.getRoleInSystem() == 1) {
                String account = request.getParameter("account");
                String password = request.getParameter("password");
                String lastName = request.getParameter("lastName");
                String firstName = request.getParameter("firstName");
                String birthdayStr = request.getParameter("birthday");
                Date birthday = null;
                try {
                    birthday = Date.valueOf(birthdayStr);
                } catch (Exception ex) {
                    // Log the error or display it to the UI
                    ex.printStackTrace();
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    return;
                }
                boolean gender = request.getParameter("gender").equals("male");
                String phone = request.getParameter("phone");
                boolean isUse = request.getParameter("isActive") != null;
                int roleInSystem = request.getParameter("role").equals("Administrator") ? 1 : 2;
                Account newAccount = new Account(account, password, lastName, firstName, birthday, gender, phone, isUse, roleInSystem);
                AccountDAO accountDAO = new AccountDAO();
                accountDAO.insertRec(newAccount);
            } 
        }
    }
    
    private String updateAccountDoGet(HttpServletRequest request) {
        String url = "account/updateAccount.jsp";
        // Get the account ID from the request parameter  
        String accountId = request.getParameter("account");
        // Fetch the account details from the database 
        Account account = accountDAO.getObjectById(accountId);
        // Set the account details in the request object  
        request.setAttribute("account", account);
        return url;
    }
    
    private void updateAccount(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        if (session != null && session.getAttribute("account") != null) {
            Account acc = (Account) session.getAttribute("account");
            if (acc.getRoleInSystem() == 1) {
                String account = request.getParameter("account");
                String password = request.getParameter("password");
                String lastName = request.getParameter("lastName");
                String firstName = request.getParameter("firstName");
                String birthdayStr = request.getParameter("birthday");
                Date birthday = null;
                try {
                    birthday = Date.valueOf(birthdayStr);
                } catch (Exception ex) {
                    // Log the error or display it to the UI      
                    ex.printStackTrace();
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    return;
                }
                boolean gender = request.getParameter("gender").equals("male");
                String phone = request.getParameter("phone");
                boolean isUse = request.getParameter("isActive") != null;
                int roleInSystem = request.getParameter("role").equals("Administrator") ? 1 : 2;
                Account updatedAccount = new Account(account, password, lastName, firstName, birthday, gender, phone, isUse, roleInSystem);
                int rowsAffected = accountDAO.updateRec(updatedAccount);
            } 
        }
        
    }
    
    private String isUseAccount(HttpServletRequest request) {
        String url = "account/dashboardAccount.jsp";
        String accountId = request.getParameter("account");
        Account account = accountDAO.getObjectById(accountId);
        if (account != null) {
            account.setUse(!account.isUse());
            int rowsAffected = accountDAO.updateRec(account);
            if (rowsAffected == 0) {
                // Log the error or display it to the UI             
                url = "account/dashboardAccount.jsp";
            }
        } else {
            // Log the error or display it to the UI   
            url = "account/dashboardAccount.jsp";
        }
        List<Account> accounts = accountDAO.listAll();
        request.setAttribute("accounts", accounts);
        return url;
    }
    
    private void deleteAccount(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        if (session != null && session.getAttribute("account") != null) {
            Account acc = (Account) session.getAttribute("account");
            if (acc.getRoleInSystem() == 1) {
                String accountId = request.getParameter("account");
                Account account = accountDAO.getObjectById(accountId);
                int rowsAffected = accountDAO.deleteRec(account);
                List<Account> accounts = accountDAO.listAll();
                request.setAttribute("accounts", accounts);
            } 
        }
    }
    
}
