/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller.product;

import dal.CategoryDAO;
import dal.ProductDAO;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Account;
import model.Category;
import model.Product;

public class ProductServlet extends HttpServlet {

    private ProductDAO productDAO = null;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        boolean noPermission = false;
        if (session != null && session.getAttribute("account") != null) {
            Account acc = (Account) session.getAttribute("account");

            productDAO = new ProductDAO();
            List<Product> products;
            List<Category> listCategory = new CategoryDAO().listAll();
            request.setAttribute("listCategory", listCategory);
            String action = request.getParameter("action") == null
                    ? ""
                    : request.getParameter("action");
            String url = "product/listProduct.jsp";
            switch (action) {
                case "showProduct":
                    url = "product/listProduct.jsp";
                    String search = request.getParameter("search");
                    if (search == null) {
                        search = "";
                    }
                    products = productDAO.listAllSearch(search);
                    request.setAttribute("search", search);
                    request.setAttribute("products", products);
                    break;
                case "addProduct":
                    if (acc.getRoleInSystem() != 1) {
                        noPermission = true;
                    }
                    url = "product/addProduct.jsp";
                    break;
                case "updateProduct":
                    if (acc.getRoleInSystem() != 1) {
                        noPermission = true;
                    }
                    url = updateProductDoGet(request, response);
                    break;
                case "deleteProduct":
                    if (acc.getRoleInSystem() != 1) {
                        noPermission = true;
                    }
                    url = deleteProductDoGet(request, response);
                    break;
                default:
                    url = "product/listProduct.jsp";
                    products = productDAO.listAll();
                    request.setAttribute("products", products);
                    break;
            }
            if (noPermission) {
                response.sendRedirect("no-permission.jsp");
            } else {
                request.getRequestDispatcher(url).forward(request, response);
            }
        } else {
            response.sendRedirect("login.jsp");
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        productDAO = new ProductDAO();
        List<Category> listCategory = new CategoryDAO().listAll();
        request.setAttribute("listCategory", listCategory);
        String action = request.getParameter("action") == null
                ? ""
                : request.getParameter("action");
        switch (action) {
            case "addProduct":
                addProductDoPost(request, response);
                break;
            case "updateProduct":
                updateProductDoPost(request, response);
                break;
            default:

        }
        response.sendRedirect("product");
    }

    private void addProductDoPost(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession();
            if (session != null && session.getAttribute("account") != null) {
                Account acc = (Account) session.getAttribute("account");
                if (acc.getRoleInSystem() == 1) {
                    String productId = request.getParameter("productId");
                    String productName = request.getParameter("productName");
                    String brief = request.getParameter("brief");
                    int typeId = Integer.parseInt(request.getParameter("typeId"));
                    String accountId = request.getParameter("account");
                    String unit = request.getParameter("unit");
                    String price_raw = request.getParameter("price");
                    int price = 0;
                    if (price_raw != null && !price_raw.isEmpty()) {
                        price = Integer.parseInt(price_raw);
                    }
                    String discount_raw = request.getParameter("discount");
                    int discount = 0;
                    if (discount_raw != null && !discount_raw.isEmpty()) {
                        discount = Integer.parseInt(discount_raw);
                    }
                    Product newProduct = new Product(productId, productName, null, brief, null,
                            new Category(typeId),
                            new Account(accountId), unit, price, discount);
                    int rowsAffected = productDAO.insertRec(newProduct);
                }

            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private String updateProductDoGet(HttpServletRequest request, HttpServletResponse response) {
        String url = null;
        List<Product> products;
        try {
            HttpSession session = request.getSession();
            if (session != null && session.getAttribute("account") != null) {
                Account acc = (Account) session.getAttribute("account");
                if (acc.getRoleInSystem() == 1) {
                    String productId = request.getParameter("productId");
                    Product product = productDAO.getObjectById(productId);
                    if (product != null) {
                        request.setAttribute("product", product);
                        request.setAttribute("listCategory", new CategoryDAO().listAll());
                        url = "product/updateProduct.jsp";
                    } else {
                        url = "product/listProduct.jsp";
                        products = productDAO.listAll();
                        request.setAttribute("products", products);
                    }
                }

            }
        } catch (Exception e) {
            url = "product/listProduct.jsp";
            products = productDAO.listAll();
            request.setAttribute("products", products);
        }
        return url;
    }

    private void updateProductDoPost(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession();
            if (session != null && session.getAttribute("account") != null) {
                Account acc = (Account) session.getAttribute("account");
                if (acc.getRoleInSystem() == 1) {

                    String productId = request.getParameter("productId");
                    String productName = request.getParameter("productName");
                    String brief = request.getParameter("brief");
                    int typeId = Integer.parseInt(request.getParameter("typeId"));
                    String unit = request.getParameter("unit");
                    String price_raw = request.getParameter("price");
                    int price = 0;
                    if (price_raw != null && !price_raw.isEmpty()) {
                        price = Integer.parseInt(price_raw);
                    }
                    String discount_raw = request.getParameter("discount");
                    int discount = 0;
                    if (discount_raw != null && !discount_raw.isEmpty()) {
                        discount = Integer.parseInt(discount_raw);
                    }
                    Product updatedProduct = new Product(productId, productName, null, brief, null, new Category(typeId), null, unit, price, discount);
                    int rowsAffected = productDAO.updateRec(updatedProduct);
                    if (rowsAffected > 0) {
                        request.setAttribute("message", "Product updated successfully!");
                    } else {
                        request.setAttribute("message", "Error updating product.");
                    }
                }
            }
        } catch (Exception e) {
            request.setAttribute("message", "Error updating product: " + e.getMessage());
            System.out.println(e.getMessage());
        }
    }

    private String deleteProductDoGet(HttpServletRequest request, HttpServletResponse response) {
        String url = "product/listProduct.jsp";
        String productId = request.getParameter("productId");
        List<Product> products;
        try {
            HttpSession session = request.getSession();
            if (session != null && session.getAttribute("account") != null) {
                Account acc = (Account) session.getAttribute("account");
                if (acc.getRoleInSystem() == 1) {
                    Product product = productDAO.getObjectById(productId);
                    if (product != null) {
                        int rowsAffected = productDAO.deleteRec(product);
                        if (rowsAffected > 0) {
                            request.setAttribute("message", "Product deleted successfully!");
                        } else {
                            request.setAttribute("message", "Error deleting product.");
                        }
                    } else {
                        request.setAttribute("message", "Product not found.");
                    }
                }

            }
        } catch (Exception e) {
            request.setAttribute("message", "Error deleting product: " + e.getMessage());
        }
        products = productDAO.listAll();
        request.setAttribute("products", products);
        return url;
    }
}
