/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MainController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String url = null;
        try {
            String action = request.getParameter("action") == null
                    ? "default"
                    : request.getParameter("action");
            switch (action) {
                case "logOut":
                    url = "authen?action=logOut";
                    break;
                case "showAccount":
                    url = "dashboardAccount?action=showAccount";
                    break;
                case "addAccount":
                    url = "dashboardAccount?action=addAccount";
                    break;
                case "updateAccount":
                    url = "dashboardAccount?action=updateAccount";
                    break;
                case "isUseAccount":
                    url = "dashboardAccount?action=isUseAccount";
                    break;
                case "deleteAccount":
                    url = "dashboardAccount?action=deleteAccount";
                    break;
                case "showCategory":
                    url = "category?action=showCategory";
                    break;
                case "addCategory":
                    url = "category?action=addCategory";
                    break;
                case "updateCategory":
                    url = "category?action=updateCategory";
                    break;
                case "deleteCategory":
                    url = "category?action=deleteCategory";
                    break;
                case "showProduct":
                    url = "product?action=showProduct";
                    break;
                case "addProduct":
                    url = "product?action=addProduct";
                    break;
                case "updateProduct":
                    url = "product?action=updateProduct";
                    break;
                case "deleteProduct":
                    url = "product?action=deleteProduct";
                    break;
                default:
                    throw new AssertionError();
            }

        } catch (Exception e) {
            System.out.println("MainController: " + e.getMessage());
        }
        request.getRequestDispatcher(url).forward(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String url = null;
        try {
            String action = request.getParameter("action") == null
                    ? "default"
                    : request.getParameter("action");
            switch (action) {
                case "login":
                    url = "authen?action=login";
                    break;
                case "addAccount":
                    url = "dashboardAccount?action=addAccount";
                    break;
                case "updateAccount":
                    url = "dashboardAccount?action=updateAccount";
                    break;
                case "addCategory":
                    url = "category?action=addCategory";
                    break;
                case "updateCategory":
                    url = "category?action=updateCategory";
                    break;
                case "addProduct":
                    url = "product?action=addProduct";
                    break;
                case "updateProduct":
                    url = "product?action=updateProduct";
                    break;
                default:
                    throw new AssertionError();
            }

        } catch (Exception e) {
            System.out.println("MainController: " + e.getMessage());
        }
        request.getRequestDispatcher(url).forward(request, response);
    }

}
